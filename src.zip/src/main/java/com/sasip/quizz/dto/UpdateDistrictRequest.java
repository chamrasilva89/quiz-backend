package com.sasip.quizz.dto;

import lombok.Data;

@Data
public class UpdateDistrictRequest {
    private String name;
    private String province;
}
