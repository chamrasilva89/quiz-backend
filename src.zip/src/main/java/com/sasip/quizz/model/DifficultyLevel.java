package com.sasip.quizz.model;

public enum DifficultyLevel {
    EASY,
    MEDIUM,
    HARD
}
