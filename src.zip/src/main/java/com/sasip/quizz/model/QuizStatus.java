package com.sasip.quizz.model;

public enum QuizStatus {
    DRAFT,
    PUBLISHED,
    ACTIVE,
    INACTIVE,
    CLOSED,
    ARCHIVED,
    EXPIRED
}
