package com.sasip.quizz.model;

public enum QuizType {
    SASIP,
    DYNAMIC,
    MYQUIZ
}