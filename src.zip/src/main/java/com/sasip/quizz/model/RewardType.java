package com.sasip.quizz.model;

public enum RewardType {
    DAILY_STREAK,
    SASIP_QUIZ,
    CLAIM_POINTS
}
