package com.sasip.quizz.model;

public enum RewardStatus {
    ACTIVE,
    DISABLED
}
